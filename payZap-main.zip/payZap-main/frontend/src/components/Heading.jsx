export const Heading = ({heading}) => {
    return <div className="text-4xl font-bold pt-5">
        {heading}
    </div>
}