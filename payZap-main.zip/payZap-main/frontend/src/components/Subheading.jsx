export const Subheading = ({text}) => {
    return <div className="text-md font-medium pt-2 text-gray-600 text-center px-10">
        {text}
    </div>
}